function [ lb, ub ] = terminate_benchmark( number )
%UNTÝTLED3 Summary of this function goes here
%   Detailed explanation goes here

    if(number == 1)
        lb = -100; ub = 100;
    end

    if(number == 2)
        lb = -100; ub = 100;
    end
    
    if(number == 3)
        lb = -100; ub = 100;
    end
    
    if(number == 4)
        lb = -10; ub = 10;
    end
    
    if(number == 5)
        lb = -100; ub = 100;
    end
    
    if(number == 6)
        lb = -10; ub = 10;
    end

    if(number == 7)
        lb = -600; ub = 600;
    end
    
    if(number == 8)
        lb = -100; ub = 100;
    end
    
    if(number == 9)
        lb = -10; ub = 10;
    end
    
    if(number == 10)
        lb = 0; ub = pi;
    end
    
    if(number == 11)
        lb = -50; ub = 50;
    end
 
    if(number == 12)
        lb = -50; ub = 50;
    end
    
    if(number == 13)
        lb = -4; ub = 5;
    end
    
    if(number == 14)
        lb = -100; ub = 100;
    end
    
    if(number == 15)
        lb = -10; ub = 10;
    end
    
    if(number == 16)
         lb = -100; ub = 100;
    end
    
    if(number == 17)
        lb = -100; ub = 100;
    end
    
    if(number == 18)
        lb = -100; ub = 100;
    end
    
    if(number == 19)
        lb = -500; ub = 500;
    end
    
    if(number == 20)
        lb = -100; ub = 100;
    end
    
    if(number == 21)
        lb = -100; ub = 100;
    end
    
    if(number == 22)
        lb = -10; ub = 10;
    end
    
    if(number == 23)
        lb = -100; ub = 100;
    end
    
    if(number == 24)
        lb = -100; ub = 100;
    end
    
    if(number == 25)
        lb = -5; ub = 5;
    end
    
    if(number == 26)
        lb = -10; ub = 10;
    end
    
    if(number == 27)
        lb = -10; ub = 10;
    end
    
    if(number == 28)
        lb = -10; ub = 10;
    end
    
    if(number == 29)
        lb = -1; ub = 1;
    end
    
    if(number == 30)
        lb = -5; ub = 10;
    end
end

